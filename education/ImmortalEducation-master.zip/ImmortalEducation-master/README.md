# ImmortalEducation
<strong>Note to developers:</strong><br /> Use templateImmortals.txt as a start to all pages (they are already styled.)
When updating to new style instead of Google Docs. Do not put the "test yourself" section <i>I (dude2093350) will do that!</i>
Please put the alert found on alliance rules on all new pages. Do not edit a page you have not been asked to edit, pull requests
will be reviewed every couple of days. Issues should only be opened on actual issues, if you have a question or comment, contact me (dude2093350) in #all-member-chat. You must watch the repository dude2093350/ImmortalEducation and you are responsible for making sure your forks are up to date.<br> Please only edit the repository ImmortalEducation, we do not currently need developers for TheImmortals. That is another project for another day :-)

<br />
New update: contact me in #tech-support instead of #all-member-chat
